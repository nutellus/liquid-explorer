# 0.2.0-alpha.4 — experimental folder tiles

- Tile button creates a separate draggable folder widget with up to nine Windows
  Shell icons. Click it to open a compact, borderless three-column folder panel.
- Escape or loss of focus closes the panel; right-click the tile to refresh/close.
- Command line: LiquidExplorer.exe --tile "C:\path\folder".
- This is a normal user-space widget, not a native Explorer desktop icon.
  Tiles are not persisted/recreated automatically yet. Native tile rendering,
  multi-monitor placement and focus behavior require real Windows validation.
- No Explorer injection, global click hooks or changes to desktop file associations.

# 0.1.2-alpha.3

- Ctrl+click or Ctrl+Enter opens a folder in another native window without losing
  the current location. The same action is available from the context menu.
- Right-click / Shift+F10: preview/open, new floating folder, show in Explorer,
  copy path. Keyboard menu navigation, Escape and viewport clamping are supported.
- Added persistent List/Grid mode with file size, type and modification date.
- Fixed a queued scroll event dismissing a newly opened context menu in compact windows.
- Clipboard and Shell actions validate that their target belongs to the current
  directory view. Filesystem existence checks run on a background worker.
- Eleven core checks, ten model tests and fourteen browser scenarios pass.
  Native new-window/Explorer/clipboard actions still require Windows validation.

# 0.1.1-alpha.2

- Removed the large cursor-following highlight and its pointer event/render loop.
- Folder contents expand from the selected tile; preview opens and closes with
  a matching spring animation. Reduced motion and zero duration are respected.
- Added breadcrumbs, Up/Alt+Up, Ctrl+F, F5 and tile arrow/Home/End navigation.
- Back/forward restore search, scroll, loaded item count and keyboard focus.
- Preview supports previous/next files, Escape and backdrop dismissal.
- Request IDs prevent stale folder/preview responses and errors from replacing
  newer content. Failed navigation retains the previous folder and history.
- Added real-browser interaction and motion tests plus path parsing checks.

Native Windows frame remains; opening from a desktop icon itself and desktop
refraction are not implemented. Existing settings stay in LocalAppData; extract
this update to a new folder, close the old application, then run the new EXE.
If autostart/context-menu integration was enabled, disable it in the old copy
before moving to the new executable, then re-enable it in the new copy.
