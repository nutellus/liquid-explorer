# Liquid Explorer

A Windows 11 folder browser built with C#/.NET 8, Windows Forms and WebView2.
[Русский](README.md). This is a real filesystem application, with a local web UI
inside a native process. It is a pre-release: cross-build and automated core/UI
checks are available; the user confirmed basic launch of the first alpha on Windows. Full Windows
Shell/DPI/performance validation remains outstanding.

## Build

Install .NET 8 SDK and the Microsoft Edge WebView2 Evergreen Runtime on Windows 11.

```powershell
dotnet run --project src/LiquidExplorer -- "C:\Users"
./scripts/build.ps1
# or: ./scripts/build.ps1 -Runtime win-arm64
./artifacts/win-x64/LiquidExplorer.exe "C:\Users"
```

Extract the entire ZIP to a permanent directory. Self-contained releases include
.NET; WebView2 Runtime remains a separate prerequisite. Linux supports cross-build
with `dotnet build src/LiquidExplorer`, but cannot run this Windows Forms GUI.

## Features

Folders expand from the selected tile; previews animate back to their source.
No cursor-following glow. Back navigation restores search, scroll and focus.
Real folder navigation, history, parent navigation, breadcrumbs, path entry, local search, natural sorting,
metadata, images (PNG/JPEG/GIF/WebP) and plain-text previews (TXT/JSON/XML/MD).
Files are read asynchronously; directory requests can be cancelled. The UI renders
200 entries at a time. Preview limits: 8 MB / 100,000 text characters.
Unsupported formats, including PDF, offer the default Windows application.

Native move/resize, cursor-monitor positioning, PerMonitorV2 DPI, pinning, tray,
Escape, Alt+Left/Right, Alt+Up, Ctrl+L, Ctrl+F and F5. Arrow/Home/End keys
navigate tiles; left/right keys browse files inside preview. Ctrl+Alt+L uses RegisterHotKey and supported
Shell Automation to open the selected Explorer folder or current directory.
When Shell selection is unavailable it shows the existing window. Desktop users
can use the optional classic context menu.

Settings open in a separate window: appearance, glass intensity, surface opacity,
blur, animation duration/stiffness, corners, default dimensions, theme, reduced
motion, Ctrl+Alt+L/E/F, focus-loss behavior, autostart and folder context menu.
Settings live in `%LOCALAPPDATA%\LiquidExplorer\settings.json`; WebView profile
lives alongside it. Registry integration changes only HKCU after an explicit Save.
Toggle it off before moving/removing the application. Optional reversible scripts
are in `scripts`; these do not synchronize the settings checkboxes.

Click a file to preview, then choose Open in default app. The minus button hides
the window in the tray; close exits that window. No file contents are transmitted,
no user files are edited, and no Explorer injection or double-click hooks are used.

## Visual scope and limitations

The SVG displacement lens refracts an application-owned background. It does not
capture or refract the desktop behind the native window. Surface opacity is
internal. The Windows frame is retained for reliable native movement/resizing;
opening/closing animations affect the content. See [architecture](docs/ARCHITECTURE.md)
for the optics model and evaluated Windows alternatives. 60 FPS is a target,
not a measured guarantee. PDF rendering, native thumbnails, modern context-menu
extensions and real desktop refraction are not implemented. Multiple processes
may compete for the global hotkey; failures are reported.

## Verify and distribute

```powershell
node tests/model.test.cjs
dotnet run --project tests/CoreChecks
python -m pip install -r tests/requirements-ui.txt
python -m playwright install chromium
python tests/ui_smoke.py
```

Windows CI builds, tests and uploads a portable ZIP. CI was prepared, not remotely
executed here. No installer, signing or release publication is performed.
Follow [Windows validation](docs/VALIDATION.md) before release.
Own code: MIT. [Third-party notices](docs/THIRD-PARTY.md) travel with distributions.
