# Architecture and rendering decisions

## Boundaries

`Files.cs` has no UI dependency: enumeration, metadata and bounded previews.
`ExplorerWindow.cs` is the native host, validates the document origin, dispatches
an explicit command allowlist, tracks files in the displayed directory, starts
shell operations and manages cancellable navigation. `ShellIntegration.cs` uses
RegisterHotKey and Shell.Application automation, never injection or hooks.
`UserIntegration.cs` changes only named HKCU keys after an explicit settings change.
`Preferences.cs` saves via a temporary file and replacement. `UI/model.js` handles
search/sort; `app.js` binds views to the native message protocol; `motion.js` owns cancellable
Web Animations and honors system/app reduced motion, including a zero-duration setting. `optics.js` builds
the displacement field. No web server or runtime npm dependency is involved.

The UI is served from a virtual WebView2 host. External navigation, downloads,
new windows and permissions are blocked. CSP disallows network connections,
frames and object plugins. File names/text are assigned with textContent.
Image previews are restricted to raster formats, not SVG or arbitrary HTML.
Default-app launching is an explicit action: Windows associations may execute
programs, so a user should open only files they trust. The app does not elevate.

Enumeration runs on a worker thread with cancellation between entries. Results
are accepted only for the latest generation. Sorting is in the UI; rendering is
paged at 200 entries. Enumeration still retains a complete metadata list, so
million-entry folders and slow network shares require further profiling. OS calls
on a blocked network share cannot necessarily be interrupted immediately.

## Optics research

Reference read during development:
https://kube.io/blog/liquid-glass-css-svg/

The article describes a convex thickness profile, its derivative as the surface
normal, Snell refraction, RGB encoding of a displacement field, SVG
feDisplacementMap, and specular lighting. Its browser demo relies on experimental
Chromium SVG backdrop-filter behavior and does not provide access to desktop
pixels outside a web document.

Our independent implementation uses a rounded-rectangle distance field and a
convex squircle height profile. A 128-sample lookup computes refraction with
n_air=1, n_glass=1.5. Red/green channels encode normal-aligned displacement;
feDisplacementMap applies it to an application-owned gradient background.
CSS blur and static edge highlights add surface cues. The large cursor-following
light was removed in response to user feedback. This is
an approximate single-interface lens model, not a physically complete renderer.
The effect is subtle on gradients. Unlike the article's experimental backdrop
filter, the ordinary SVG filter path has a predictable fallback background.

Maps are bounded to 384 pixels in width and rebuilt on resize, rather than every
animation frame. There is no pointer-tracking rendering loop.
Folder navigation expands the new content from the selected tile using sampled
spring transforms. Preview opening/closing uses the same geometry; back navigation
restores position and focus. Request IDs discard stale results and errors.
These transitions take place inside the application, not from desktop icons. Reduced motion follows
both the application setting and the system browser preference. No 60 FPS claim
is made until representative Windows hardware has been measured.

## Why this does not refract the desktop

A WebView2 document can sample its own composited content, not arbitrary pixels
from other HWNDs. A transparent WebView background does not make desktop pixels
available to an SVG filter. This build retains a native Windows frame for moving,
resizing and DPI support. The animation applies to content inside that frame.

Alternatives evaluated at architecture level (not prototyped):

* DWM system backdrops / Mica / Desktop Acrylic provide native material effects
  but do not expose the backdrop as a texture for a custom refraction shader.
* Windows Composition backdrop brushes and graphics effects can improve native
  blur/material composition; custom displacement requires a suitable sampled
  texture and potentially a different presentation architecture.
* Windows.Graphics.Capture can supply frames of a selected monitor/window, but
  introduces capture permission/UX, self-capture exclusion, privacy, latency,
  HDR and multi-monitor synchronization concerns. A D3D renderer with an explicit
  opt-in capture mode is a possible future implementation, not silently enabled.
* Undocumented SetWindowCompositionAttribute tricks are deliberately avoided.

References for the next native validation stage:
https://learn.microsoft.com/microsoft-edge/webview2/concepts/overview-features-apis
https://learn.microsoft.com/windows/apps/desktop/modernize/apply-mica-win32
https://learn.microsoft.com/windows/uwp/audio-video-camera/screen-capture
https://learn.microsoft.com/windows/win32/api/winuser/nf-winuser-registerhotkey

## Remaining scope

Desktop icon selection through Shell Automation varies by Shell version; the
supported alternative here is the classic folder context command. There is no
single-instance IPC, so different processes may compete for the global shortcut.
COM enumeration is restricted to the foreground Explorer window. Native Shell
and monitor/DPI behavior require real Windows testing. PDF preview falls back to
the default app; native icons/thumbnails, an installer and code signing remain
future work. This is a functional pre-release foundation, not full fulfillment
of every visual and integration requirement in the original specification.
