# Validation record and Windows acceptance

## Automated checks in this Linux environment

* C# cross-build: `dotnet build src/LiquidExplorer -c Release`.
* Core checks: `dotnet run --project tests/CoreChecks -c Release`; nine assertions
  exercise actual temporary files: enumeration, Unicode, untrusted text preview,
  unsupported extension fallback, size cap, missing-directory errors, cancellation,
  text truncation and raster previews.
* UI model: `node tests/model.test.cjs`; ten tests exercise directory grouping,
  natural order, descending size, Unicode/case search, immutability, sizes and
  drive/UNC/extended-path breadcrumbs.
* Chromium: `python tests/ui_smoke.py` with Playwright and an injected bridge.
  Ten scenarios exercise hostile text, removal of pointer glow, folder/preview
  animation, restored history state, stale-response handling, errors, breadcrumbs,
  keyboard navigation, file switching, reduced/zero motion and native settings
  window requests. Native WebView2 and Shell behavior are not covered by this mock.
* Packaging: self-contained win-x64 cross-publish. Compilation is not a Windows
  launch test. The user confirmed that the first alpha opens on Windows; detailed
  Windows checks and a remote Actions run remain outstanding.

On systems with a preinstalled Chromium, set `LIQUID_TEST_BROWSER` to its path.
The app and core tests have no Python dependency; Python/Playwright is test-only.

## Required manual Windows 11 checks before release

1. Extract the entire ZIP, launch with and without a directory argument. Repeat
   with WebView2 absent: verify the Runtime prerequisite error is understandable.
2. Browse Unicode and >260-character paths; try a permission-denied directory,
   removed file, disconnected share and rapid navigation. UI must remain usable;
   stale results must not replace the current folder.
3. Exercise PNG/JPEG/WebP/GIF, UTF-8/UTF-16 text, oversized text, malformed raster
   input, PDF fallback, and default app opening. Test file contents containing HTML.
4. Back/forward, keyboard Tab/Enter/Escape/Alt+arrows/Ctrl+L, search, every sort,
   reload, empty folders and at least a 10,000-entry folder.
5. Drag/resize across monitors with negative coordinates and 125%, 150%, 200% DPI;
   test work-area placement, taskbar auto-hide, pinning and focus-loss hiding.
6. Tray show/exit, multiple windows, closing the initial window while another is
   open, global shortcut registration conflicts, selected Explorer folders,
   desktop context menu, settings changes and persistence across restart.
7. Enable/disable HKCU context menu and autostart from Settings; verify both
   registry additions and removal. Recheck after moving the EXE. No admin prompt.
8. System/app light/dark themes, high contrast, screen reader names, reduced motion,
   save feedback, opening/closing animations. Measure frame times and idle memory
   with Windows performance tools; 60 FPS and memory targets are not yet certified.
9. Review ZIP third-party notices, test on a clean machine without .NET installed,
   and verify no user file changes or file-content network transmission.

Do not publish a stable release until Windows checks are recorded with OS version,
GPU, DPI/monitor configuration and WebView2 Runtime version.
