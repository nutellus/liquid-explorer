# 0.1.1-alpha.2

- Removed the large cursor-following highlight and its pointer event/render loop.
- Folder contents expand from the selected tile; preview opens and closes with
  a matching spring animation. Reduced motion and zero duration are respected.
- Added breadcrumbs, Up/Alt+Up, Ctrl+F, F5 and tile arrow/Home/End navigation.
- Back/forward restore search, scroll, loaded item count and keyboard focus.
- Preview supports previous/next files, Escape and backdrop dismissal.
- Request IDs prevent stale folder/preview responses and errors from replacing
  newer content. Failed navigation retains the previous folder and history.
- Added real-browser interaction and motion tests plus path parsing checks.

Native Windows frame remains; opening from a desktop icon itself and desktop
refraction are not implemented. Existing settings stay in LocalAppData; extract
this update to a new folder, close the old application, then run the new EXE.
If autostart/context-menu integration was enabled, disable it in the old copy
before moving to the new executable, then re-enable it in the new copy.
