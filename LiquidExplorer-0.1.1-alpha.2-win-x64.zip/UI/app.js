'use strict';
const $ = id => document.getElementById(id);
const send = (command, value, requestId) => window.chrome.webview.postMessage({ command, value, requestId });
const motion = LiquidMotion;
let entries = [], history = [], position = -1, pending = null, sequence = 0;
let selected = null, previewId = 0, previewSource = null, previewClosing = false;
let descending = false, settings = {}, settingsMode = false, limit = 200, opened = false, closing = false;

function remember() {
  if (position < 0) return;
  Object.assign(history[position], {
    scroll: $('files').scrollTop, query: $('search').value, limit,
    focus: document.activeElement?.closest('.file')?.dataset.path ?? history[position].focus
  });
}
function navigate(path, target = null, source = null) {
  if (!path || closing || settingsMode) return;
  remember();
  pending = { id: ++sequence, target, source, backward: target !== null && target < position };
  $('error').hidden = true;
  $('count').textContent = 'Opening folder…';
  $('files').setAttribute('aria-busy', 'true');
  $('shell').classList.add('loading');
  send('navigate', path, pending.id);
}
function updateNavigation() {
  $('back').disabled = position <= 0;
  $('forward').disabled = position >= history.length - 1;
  const crumbs = LiquidModel.breadcrumbs(history[position]?.path ?? '');
  $('up').disabled = crumbs.length < 2;
  $('breadcrumbs').replaceChildren();
  for (const [index, crumb] of crumbs.entries()) {
    const button = document.createElement('button');
    button.textContent = crumb.name; button.title = crumb.path;
    if (index === crumbs.length - 1) button.setAttribute('aria-current', 'location');
    button.onclick = () => { if (index < crumbs.length - 1) navigate(crumb.path); };
    $('breadcrumbs').append(button);
  }
  $('breadcrumbs').scrollLeft = $('breadcrumbs').scrollWidth;
}
function visibleFiles() { return LiquidModel.select(entries, $('search').value, $('sort').value, descending); }
function tile(path) { return [...$('files').querySelectorAll('.file')].find(element => element.dataset.path === path); }
function render() {
  const list = visibleFiles();
  $('files').replaceChildren();
  const fragment = document.createDocumentFragment();
  for (const entry of list.slice(0, limit)) {
    const item = document.createElement('button');
    item.className = 'file'; item.dataset.path = entry.path;
    const icon = document.createElement('span');
    icon.className = entry.directory ? 'icon folder' : 'icon';
    icon.textContent = entry.directory ? '' : '▤'; icon.setAttribute('aria-hidden', 'true');
    const name = document.createElement('span'); name.className = 'name'; name.textContent = entry.name;
    const meta = document.createElement('small'); meta.textContent = entry.directory ? 'Folder' : LiquidModel.bytes(entry.size);
    item.append(icon, name, meta); item.title = entry.name;
    item.onclick = () => {
      if (entry.directory) navigate(entry.path, null, item.getBoundingClientRect());
      else preview(entry, item);
    };
    fragment.append(item);
  }
  if (!list.length) {
    const empty = document.createElement('p'); empty.className = 'empty';
    empty.textContent = entries.length ? 'No matching files' : 'This folder is empty'; fragment.append(empty);
  }
  if (list.length > limit) {
    const more = document.createElement('button'); more.className = 'load-more'; more.textContent = 'Show next 200';
    more.onclick = () => { const scroll = $('files').scrollTop; limit += 200; render(); $('files').scrollTop = scroll; }; fragment.append(more);
  }
  $('files').append(fragment);
  $('count').textContent = `${list.length} items`;
  updateNavigation();
}
function finishLoading() {
  $('files').setAttribute('aria-busy', 'false'); $('shell').classList.remove('loading');
}
function folder(data) {
  if (pending ? data.requestId !== pending.id : data.requestId !== 0 || position !== -1) return;
  const transition = pending;
  entries = data.entries;
  if (transition?.target !== null && transition?.target !== undefined) position = transition.target;
  else if (history[position]?.path !== data.path) {
    history = history.slice(0, position + 1); history.push({ path: data.path, scroll: 0, query: '', limit: 200 }); position++;
  }
  const saved = history[position];
  pending = null; finishLoading(); $('address').value = data.path;
  limit = saved.limit; $('search').value = saved.query; render();
  $('files').scrollTop = saved.scroll;
  if (transition) {
    (tile(saved.focus) ?? $('files')).focus({ preventScroll: true });
    motion.open($('files'), transition.source, transition.backward);
  }
}
function preview(entry, source = null) {
  selected = entry; previewClosing = false;
  const requestId = ++previewId;
  const wasOpen = $('preview').open;
  if (!wasOpen) previewSource = source;
  $('previewName').textContent = entry.name;
  $('metadata').textContent = [LiquidModel.bytes(entry.size), entry.type, new Date(entry.modified).toLocaleString()].join(' · ');
  $('previewContent').textContent = 'Loading preview…';
  $('previewContent').setAttribute('aria-busy', 'true');
  const files = visibleFiles().filter(file => !file.directory);
  const index = files.findIndex(file => file.path === entry.path);
  $('previousFile').disabled = index <= 0;
  $('nextFile').disabled = index < 0 || index >= files.length - 1;
  $('previewPosition').textContent = index < 0 ? '' : `${index + 1} / ${files.length}`;
  if (!wasOpen) { $('preview').showModal(); motion.open($('preview'), source?.getBoundingClientRect()); }
  send('preview', entry.path, requestId);
}
async function dismissPreview() {
  if (previewClosing || !$('preview').open) return;
  previewClosing = true; ++previewId; selected = null;
  $('previousFile').disabled = $('nextFile').disabled = true;
  await motion.close($('preview'), previewSource?.isConnected ? previewSource.getBoundingClientRect() : null);
  $('preview').close(); previewClosing = false;
  if (previewSource?.isConnected) previewSource.focus({ preventScroll: true });
}
function nextPreview(direction) {
  if (!selected || previewClosing) return;
  const files = visibleFiles().filter(file => !file.directory);
  const next = files[files.findIndex(file => file.path === selected.path) + direction];
  if (next) preview(next);
}
function apply(value) {
  settings = value; motion.configure(value);
  document.documentElement.dataset.theme = value.theme;
  document.documentElement.dataset.reducedMotion = String(value.reducedMotion || value.speed === 0);
  const style = document.documentElement.style;
  for (const [key, val] of Object.entries({ '--glass': value.glass, '--opacity': value.opacity, '--blur': `${value.blur}px`, '--duration': `${value.reducedMotion ? 0 : value.speed}ms`, '--radius': `${value.radius}px` })) style.setProperty(key, val);
  if (!opened && !settingsMode) { opened = true; motion.open($('shell')); }
}
function error(data) {
  if (data.command === 'navigate' || data.command === 'ready') {
    if (pending && data.requestId !== pending.id) return;
    if (!pending && position >= 0) return;
    pending = null; finishLoading();
    $('address').value = history[position]?.path ?? $('address').value;
    $('count').textContent = 'Could not open folder';
  } else if (data.command === 'preview') {
    if (data.requestId === previewId && selected && !previewClosing) {
      $('previewContent').textContent = data.message; $('previewContent').setAttribute('aria-busy', 'false');
    }
    return;
  }
  $('error').textContent = data.message; $('error').hidden = false;
  if (settingsMode) $('settingsStatus').textContent = data.message;
}
window.chrome.webview.addEventListener('message', ({ data }) => {
  if (data.kind === 'folder') folder(data);
  else if (data.kind === 'error') error(data);
  else if (data.kind === 'settings') apply(data.value);
  else if (data.kind === 'settingsView') { settingsMode = true; document.body.classList.add('settings-only'); showSettings(); }
  else if (data.kind === 'closing') close();
  else if (data.kind === 'saved') $('settingsStatus').textContent = data.message;
  else if (data.kind === 'pin') $('pin').setAttribute('aria-pressed', String(data.value));
  else if (data.kind === 'preview' && data.requestId === previewId && selected?.path === data.path && !previewClosing) {
    const node = document.createElement(data.data.kind === 'image' ? 'img' : 'pre');
    if (data.data.kind === 'image') {
      node.src = data.data.value; node.alt = selected.name;
      node.onerror = () => { $('previewContent').textContent = 'This image could not be decoded. Try the default app.'; };
    } else node.textContent = data.data.value;
    $('previewContent').replaceChildren(node); $('previewContent').setAttribute('aria-busy', 'false');
  }
});
$('addressForm').onsubmit = event => { event.preventDefault(); navigate($('address').value); };
$('back').onclick = () => { if (position > 0) navigate(history[position - 1].path, position - 1); };
$('forward').onclick = () => { if (position < history.length - 1) navigate(history[position + 1].path, position + 1); };
$('up').onclick = () => { const crumbs = LiquidModel.breadcrumbs(history[position]?.path ?? ''); if (crumbs.length > 1) navigate(crumbs.at(-2).path); };
$('refresh').onclick = () => navigate(history[position]?.path ?? $('address').value, position >= 0 ? position : null);
$('search').oninput = () => { limit = 200; render(); };
$('sort').onchange = render;
$('direction').onclick = () => { descending = !descending; $('direction').textContent = descending ? '↓' : '↑'; render(); };
for (const command of ['pin', 'hide', 'explorer']) $(command).onclick = () => send(command);
async function close() { if (closing) return; closing = true; await motion.close($('shell')); send('close'); }
$('close').onclick = close;
$('dismissPreview').onclick = dismissPreview;
$('preview').addEventListener('cancel', event => { event.preventDefault(); dismissPreview(); });
$('preview').addEventListener('click', event => {
  const rect = $('preview').getBoundingClientRect();
  if (event.target === $('preview') && (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom)) dismissPreview();
});
$('previousFile').onclick = () => nextPreview(-1); $('nextFile').onclick = () => nextPreview(1);
$('openFile').onclick = () => { if (selected && !previewClosing) send('open', selected.path); };
function showSettings() {
  for (const [key, value] of Object.entries(settings)) {
    const input = $('settingsForm').elements.namedItem(key);
    if (input) { if (input.type === 'checkbox') input.checked = value; else input.value = value; }
  }
  $('preferences').showModal();
}
$('settings').onclick = () => send('settingsWindow');
$('cancelSettings').onclick = () => settingsMode ? send('close') : $('preferences').close();
$('settingsForm').onsubmit = event => {
  event.preventDefault(); const form = event.currentTarget; const next = {};
  for (const key of ['glass', 'opacity', 'blur', 'speed', 'radius', 'stiffness', 'width', 'height', 'hotkey']) next[key] = Number(form.elements.namedItem(key).value);
  next.theme = form.elements.namedItem('theme').value;
  for (const key of ['reducedMotion', 'hideOnBlur', 'autoStart', 'contextMenu']) next[key] = form.elements.namedItem(key).checked;
  send('settings', next); if (!settingsMode) $('preferences').close();
};
$('files').addEventListener('keydown', event => {
  if (!['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Home', 'End'].includes(event.key) || event.altKey || event.ctrlKey) return;
  const tiles = [...$('files').querySelectorAll('.file')];
  if (!tiles.length) return;
  event.preventDefault();
  const columns = getComputedStyle($('files')).gridTemplateColumns.split(' ').length;
  const index = Math.max(0, tiles.indexOf(document.activeElement));
  const next = { ArrowLeft: index - 1, ArrowRight: index + 1, ArrowUp: index - columns, ArrowDown: index + columns, Home: 0, End: tiles.length - 1 }[event.key];
  tiles[Math.max(0, Math.min(tiles.length - 1, next))].focus();
});
document.addEventListener('keydown', event => {
  if ($('preview').open) {
    if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') { event.preventDefault(); nextPreview(event.key === 'ArrowLeft' ? -1 : 1); }
    return;
  }
  if ($('preferences').open) { if (event.key === 'Escape' && settingsMode) { event.preventDefault(); send('close'); } return; }
  if (event.key === 'Escape') close();
  if (event.altKey && event.key === 'ArrowLeft') { event.preventDefault(); $('back').click(); }
  if (event.altKey && event.key === 'ArrowRight') { event.preventDefault(); $('forward').click(); }
  if (event.altKey && event.key === 'ArrowUp') { event.preventDefault(); $('up').click(); }
  if (event.ctrlKey && event.key.toLowerCase() === 'l') { event.preventDefault(); $('address').select(); }
  if (event.ctrlKey && event.key.toLowerCase() === 'f') { event.preventDefault(); $('search').focus(); }
  if (event.key === 'F5') { event.preventDefault(); $('refresh').click(); }
});
send('ready');
