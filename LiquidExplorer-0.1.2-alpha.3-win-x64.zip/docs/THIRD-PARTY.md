# Third-party components

Own C#, JavaScript, CSS, SVG-generation code and documentation: MIT (root LICENSE).
No Apple/Microsoft assets, article source code, fonts or remote artwork are bundled.

* Microsoft.Web.WebView2 SDK 1.0.2903.40: the installed NuGet package's BSD-style
  three-clause LICENSE.txt is reproduced in `licenses/WebView2-SDK.txt`.
  Its notice-retention and non-endorsement conditions are compatible with this
  project's MIT code. Retain it in binary distributions; the project includes docs in build/publish outputs.
* .NET / Windows Forms: MIT with associated third-party notices. Self-contained
  publish target copies runtime licenses and third-party notices from the resolved
  NuGet runtime packs to licenses/;
  distribute the entire output, not just the EXE.
* Microsoft Edge WebView2 Runtime is a separately installed Microsoft component,
  not relicensed by this project. Install through Microsoft's supported installer:
  https://developer.microsoft.com/microsoft-edge/webview2/
* Playwright (Apache-2.0) and Node.js test runner are development-only tools, not
  bundled with the application. Browser distributions retain their own licenses.

Recheck licenses and NuGet vulnerability reports when upgrading dependencies.
