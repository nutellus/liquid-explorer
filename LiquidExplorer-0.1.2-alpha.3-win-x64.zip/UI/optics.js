// Refract only an application-owned background. This never captures the desktop.
(() => {
  const ns='http://www.w3.org/2000/svg';
  const svg=document.createElementNS(ns,'svg');svg.classList.add('optics-svg');
  const filter=document.createElementNS(ns,'filter');filter.id='lens';filter.setAttribute('color-interpolation-filters','sRGB');
  const map=document.createElementNS(ns,'feImage');map.setAttribute('result','normal');map.setAttribute('preserveAspectRatio','none');map.setAttribute('x','0');map.setAttribute('y','0');map.setAttribute('width','100%');map.setAttribute('height','100%');
  const displacement=document.createElementNS(ns,'feDisplacementMap');
  for(const [k,v]of Object.entries({in:'SourceGraphic',in2:'normal',scale:'28',xChannelSelector:'R',yChannelSelector:'G'}))displacement.setAttribute(k,v);
  filter.append(map,displacement);svg.append(filter);document.body.prepend(svg);
  let last='';
  new ResizeObserver(([entry])=>{
    const w=Math.min(384,Math.round(entry.contentRect.width)),h=Math.max(1,Math.round(w*entry.contentRect.height/entry.contentRect.width));
    if(!w||last===`${w}:${h}`)return;last=`${w}:${h}`;
    const canvas=document.createElement('canvas');canvas.width=w;canvas.height=h;
    const context=canvas.getContext('2d');const pixels=context.createImageData(w,h);
    // A rounded bevel's outward normal controls the red/green displacement channels.
    const radius=16,bevel=12,thickness=14,base=4;
    // Snell's law for a normal incident ray and a convex squircle bevel (air 1, glass 1.5).
    const height=t=>Math.pow(Math.max(0,1-Math.pow(1-t,4)),.25);
    const magnitudes=Array.from({length:128},(_,i)=>{
      const t=Math.max(.001,i/127),delta=.0005;
      const slope=(height(Math.min(1,t+delta))-height(Math.max(0,t-delta)))/(2*delta)*thickness/bevel;
      const incident=Math.atan(slope), refracted=Math.asin(Math.sin(incident)/1.5);
      return (base+thickness*height(t))*Math.tan(incident-refracted);
    });
    const maximum=Math.max(...magnitudes);
    // SVG defines shift = scale * (channel - .5); twice the maximum spans both directions.
    displacement.setAttribute('scale',String(2*maximum));
    for(let y=0;y<h;y++)for(let x=0;x<w;x++){
      const dx=x-w/2,dy=y-h/2,qx=Math.abs(dx)-(w/2-radius),qy=Math.abs(dy)-(h/2-radius);
      const outside=Math.hypot(Math.max(qx,0),Math.max(qy,0));
      const distance=outside+Math.min(Math.max(qx,qy),0)-radius;
      let nx=0,ny=0;
      if(outside>0){nx=Math.sign(dx)*Math.max(qx,0)/outside;ny=Math.sign(dy)*Math.max(qy,0)/outside;}
      else if(qx>qy)nx=Math.sign(dx);else ny=Math.sign(dy);
      const strength=distance<=0&&distance>=-bevel?magnitudes[Math.min(127,Math.round(-distance/bevel*127))]/maximum:0;
      const i=(y*w+x)*4;pixels.data[i]=128+Math.round(nx*strength*110);pixels.data[i+1]=128+Math.round(ny*strength*110);pixels.data[i+2]=128;pixels.data[i+3]=255;
    }
    context.putImageData(pixels,0,0);map.setAttribute('href',canvas.toDataURL());
  }).observe(document.getElementById('shell'));
})();
