'use strict';
// Animate only local content. No desktop capture or cursor-following surface light.
window.LiquidMotion = (() => {
  let preferences = {};
  const running = new Map();
  const system = matchMedia('(prefers-reduced-motion: reduce)');
  const duration = () => preferences.reducedMotion || system.matches ? 0 : Math.max(0, Math.min(1000, preferences.speed ?? 350));
  function cancel(element) {
    running.get(element)?.cancel();
    running.delete(element);
  }
  function cancelAll() { for (const element of [...running.keys()]) cancel(element); }
  system.addEventListener('change', () => { if (system.matches) cancelAll(); });
  function configure(value) { preferences = value; if (!duration()) cancelAll(); }
  async function play(element, frames) {
    cancel(element);
    if (!duration()) return;
    const animation = element.animate(frames, { duration: duration(), easing: 'linear' });
    running.set(element, animation);
    try { await animation.finished; } catch { /* Superseded navigation or reduced motion. */ }
    finally { if (running.get(element) === animation) running.delete(element); }
  }
  function frames(element, source, reverse = false, backward = false) {
    const rect = element.getBoundingClientRect();
    const dx = source ? source.left + source.width / 2 - rect.left - rect.width / 2 : 0;
    const dy = source ? source.top + source.height / 2 - rect.top - rect.height / 2 : 14;
    const sx = source ? Math.max(.12, source.width / Math.max(1, rect.width)) : backward ? 1.06 : .94;
    const sy = source ? Math.max(.12, source.height / Math.max(1, rect.height)) : backward ? 1.06 : .94;
    const stiffness = Math.max(80, Math.min(400, preferences.stiffness ?? 200));
    return Array.from({ length: 61 }, (_, index) => {
      const t = index / 60;
      // Critically damped-looking spring with small controlled overshoot.
      const progress = index === 60 ? 1 : 1 - Math.exp(-8 * t) * Math.cos(Math.sqrt(stiffness) * t * .65);
      const p = reverse ? 1 - progress : progress;
      return {
        opacity: Math.max(0, Math.min(1, reverse ? p : p * 1.4)),
        transform: `translate(${dx * (1 - p)}px, ${dy * (1 - p)}px) scale(${sx + (1 - sx) * p}, ${sy + (1 - sy) * p})`
      };
    });
  }
  return {
    configure,
    open: (element, source = null, backward = false) => { cancel(element); return play(element, frames(element, source, false, backward)); },
    close: (element, source = null) => { cancel(element); return play(element, frames(element, source, true)); },
    cancel
  };
})();
