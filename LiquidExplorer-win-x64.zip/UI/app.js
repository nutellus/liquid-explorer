'use strict';
const $ = id => document.getElementById(id);
const send = (command,value) => window.chrome.webview.postMessage({command,value});
let entries=[], history=[], position=-1, pendingHistory=null, selected=null, descending=false, settings={}, settingsMode=false, limit=200;
function navigate(path, target=null) { pendingHistory=target; $('error').hidden=true; $('count').textContent='Loading…'; send('navigate',path); }
function render() {
  const list=LiquidModel.select(entries,$('search').value,$('sort').value,descending);
  $('files').replaceChildren();
  const fragment=document.createDocumentFragment();
  for(const entry of list.slice(0,limit)) {
    const item=document.createElement('button'); item.className='file';
    const icon=document.createElement('span'); icon.className=entry.directory?'icon folder':'icon'; icon.textContent=entry.directory?'▰':'▤';
    const name=document.createElement('span'); name.className='name'; name.textContent=entry.name;
    const meta=document.createElement('small'); meta.textContent=entry.directory?'Folder':LiquidModel.bytes(entry.size);
    item.append(icon,name,meta); item.title=entry.name; item.onclick=()=>entry.directory?navigate(entry.path):preview(entry);
    item.ondblclick=()=>{if(!entry.directory)send('open',entry.path);}; fragment.append(item);
  }
  if(!list.length){const empty=document.createElement('p');empty.className='empty';empty.textContent=entries.length?'No matching files':'This folder is empty';fragment.append(empty);}
  if(list.length>limit){const more=document.createElement('button');more.textContent='Show next 200';more.onclick=()=>{limit+=200;render();};fragment.append(more);}
  $('files').append(fragment); $('count').textContent=list.length+' items';
  $('back').disabled=position<=0; $('forward').disabled=position>=history.length-1;
}
function preview(entry){selected=entry; $('previewName').textContent=entry.name; $('metadata').textContent=[LiquidModel.bytes(entry.size),entry.type,new Date(entry.modified).toLocaleString()].join(' · ');$('previewContent').textContent='Loading…';if(!$('preview').open)$('preview').showModal();send('preview',entry.path);}
let opened=false;
function springFrames(stiffness, reverse=false){const frames=[];for(let i=0;i<=60;i++){const t=i/60;const progress=1-Math.exp(-7*t)*Math.cos(Math.sqrt(stiffness)*t);const p=reverse?1-progress:progress;frames.push({opacity:Math.max(0,Math.min(1,p)),transform:`translateY(${24*(1-p)}px) scale(${.86+.14*p},${.76+.24*p})`});}frames[60]={opacity:reverse?0:1,transform:reverse?'translateY(24px) scale(.86,.76)':'none'};return frames;}
function apply(value){settings=value;if(!opened&&!settingsMode){opened=true;if(!value.reducedMotion&&!matchMedia('(prefers-reduced-motion: reduce)').matches)$('shell').animate(springFrames(value.stiffness||200),{duration:value.speed,fill:'none'});}document.documentElement.dataset.theme=value.theme;const style=document.documentElement.style;for(const [key,val] of Object.entries({'--glass':value.glass,'--opacity':value.opacity,'--blur':value.blur+'px','--duration':(value.reducedMotion?0:value.speed)+'ms','--radius':value.radius+'px'}))style.setProperty(key,val);}
window.chrome.webview.addEventListener('message',({data})=>{
 if(data.kind==='folder'){
   entries=data.entries;limit=200;$('address').value=data.path;
   if(pendingHistory!==null){position=pendingHistory;}else if(history[position]!==data.path){history=history.slice(0,position+1);history.push(data.path);position++;}
   pendingHistory=null;$('search').value='';render();
 }else if(data.kind==='error'){$('error').textContent=data.message;$('error').hidden=false;if(settingsMode)$('settingsStatus').textContent=data.message;$('count').textContent='Unable to complete operation';pendingHistory=null;}
 else if(data.kind==='settings')apply(data.value);
 else if(data.kind==='settingsView'){settingsMode=true;document.body.classList.add('settings-only');showSettings();}
 else if(data.kind==='closing')close();
 else if(data.kind==='saved'){$('settingsStatus').textContent=data.message;}
 else if(data.kind==='pin')$('pin').setAttribute('aria-pressed',String(data.value));
 else if(data.kind==='preview' && selected?.path===data.path){$('previewContent').replaceChildren();let node=document.createElement(data.data.kind==='image'?'img':'pre');if(data.data.kind==='image'){node.src=data.data.value;node.alt=selected.name;}else node.textContent=data.data.value;$('previewContent').append(node);}
});
$('addressForm').onsubmit=e=>{e.preventDefault();navigate($('address').value);};
$('back').onclick=()=>navigate(history[position-1],position-1);$('forward').onclick=()=>navigate(history[position+1],position+1);
$('refresh').onclick=()=>navigate($('address').value,position);$('search').oninput=render;$('sort').onchange=render;
$('direction').onclick=()=>{descending=!descending;$('direction').textContent=descending?'↓':'↑';render();};
for(const command of ['pin','hide','explorer'])$(command).onclick=()=>send(command);
let closing=false;
async function close(){if(closing)return;closing=true;const reduced=settings.reducedMotion||matchMedia('(prefers-reduced-motion: reduce)').matches;if(!reduced){try{await $('shell').animate(springFrames(settings.stiffness||200,true),{duration:settings.speed||350,fill:'forwards'}).finished;}catch{}}send('close');}
$('close').onclick=close;
$('dismissPreview').onclick=()=>$('preview').close();$('openFile').onclick=()=>{if(selected)send('open',selected.path);};
function showSettings(){for(const [key,value]of Object.entries(settings)){const input=$('settingsForm').elements.namedItem(key);if(input){if(input.type==='checkbox')input.checked=value;else input.value=value;}}$('preferences').showModal();}
$('settings').onclick=()=>send('settingsWindow');
$('cancelSettings').onclick=()=>settingsMode?send('close'):$('preferences').close();
$('settingsForm').onsubmit=e=>{e.preventDefault();const form=e.currentTarget;const next={};for(const key of ['glass','opacity','blur','speed','radius','stiffness','width','height'])next[key]=Number(form.elements.namedItem(key).value);next.hotkey=Number(form.elements.namedItem('hotkey').value);next.theme=form.elements.namedItem('theme').value;next.reducedMotion=form.elements.namedItem('reducedMotion').checked;for(const key of ['hideOnBlur','autoStart','contextMenu'])next[key]=form.elements.namedItem(key).checked;send('settings',next);if(!settingsMode)$('preferences').close();};
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&settingsMode){e.preventDefault();send('close');}else if(e.key==='Escape'&&!document.querySelector('dialog[open]'))close();if(e.altKey&&e.key==='ArrowLeft'&&position>0){e.preventDefault();$('back').click();}if(e.altKey&&e.key==='ArrowRight'&&position<history.length-1){e.preventDefault();$('forward').click();}if(e.ctrlKey&&e.key==='l'){e.preventDefault();$('address').select();}});
let pointerFrame=0;document.addEventListener('pointermove',e=>{if(pointerFrame)return;pointerFrame=requestAnimationFrame(()=>{pointerFrame=0;document.documentElement.style.setProperty('--pointer-x',(e.clientX/innerWidth*100)+'%');document.documentElement.style.setProperty('--pointer-y',(e.clientY/innerHeight*100)+'%');});});
send('ready');
