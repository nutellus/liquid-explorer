(function(root) {
  function select(entries, query, sort, descending) {
    const field = { name: 'name', size: 'size', type: 'type', modified: 'modified' }[sort] || 'name';
    return entries.filter(e => e.name.toLocaleLowerCase().includes(query.toLocaleLowerCase())).sort((a,b) => {
      if(a.directory !== b.directory) return a.directory ? -1 : 1;
      const av = a[field] ?? 0, bv = b[field] ?? 0;
      const result = typeof av === 'number' ? av - bv : String(av).localeCompare(String(bv), undefined, { numeric:true });
      return descending ? -result : result;
    });
  }
  function bytes(n) { if(n === null) return 'Folder'; if(n < 1024) return n + ' B'; let i = Math.min(3, Math.floor(Math.log(n)/Math.log(1024))); return (n/1024**i).toFixed(1)+' '+['B','KB','MB','GB'][i]; }
  const api = { select, bytes }; root.LiquidModel = api;
  if(typeof module !== 'undefined') module.exports = api;
})(globalThis);
